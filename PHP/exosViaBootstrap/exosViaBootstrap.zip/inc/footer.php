    <footer class="container-fluid">
        <div class="well well-lg">
            <div class="row text-center">
                <a class="col-lg-3" href="#">un</span></a>
                <a class="col-lg-3" href="#">deux</a>
                <a class="col-lg-3" href="#">trois</a>
                <a class="col-lg-3" href="#">quatre</a>
            </div>
        </div>
    </footer>

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>

    <!-- Script to Activate the Carousel -->
</body>

</html>
